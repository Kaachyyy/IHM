#pragma once
#include "carte.h"

typedef Carte Item;//Les items que nous manipulons sont de type Carte